--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.10 (Debian 13.10-0+deb11u1)
-- Dumped by pg_dump version 13.10 (Debian 13.10-0+deb11u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE tienda2;
--
-- Name: tienda2; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE tienda2 WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'C.UTF-8';


ALTER DATABASE tienda2 OWNER TO postgres;

\connect tienda2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: categorias_ps; Type: TABLE; Schema: public; Owner: leo2
--

CREATE TABLE public.categorias_ps (
    id integer NOT NULL,
    categoria character varying(255) NOT NULL
);


ALTER TABLE public.categorias_ps OWNER TO leo2;

--
-- Name: categorias_ps_id_seq; Type: SEQUENCE; Schema: public; Owner: leo2
--

CREATE SEQUENCE public.categorias_ps_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.categorias_ps_id_seq OWNER TO leo2;

--
-- Name: categorias_ps_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: leo2
--

ALTER SEQUENCE public.categorias_ps_id_seq OWNED BY public.categorias_ps.id;


--
-- Name: cupones_descs; Type: TABLE; Schema: public; Owner: leo2
--

CREATE TABLE public.cupones_descs (
    id integer NOT NULL,
    descuento integer NOT NULL,
    dias_validez integer NOT NULL,
    activo boolean DEFAULT true NOT NULL,
    codigo character varying(255)
);


ALTER TABLE public.cupones_descs OWNER TO leo2;

--
-- Name: cupones_descs_id_seq; Type: SEQUENCE; Schema: public; Owner: leo2
--

CREATE SEQUENCE public.cupones_descs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cupones_descs_id_seq OWNER TO leo2;

--
-- Name: cupones_descs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: leo2
--

ALTER SEQUENCE public.cupones_descs_id_seq OWNED BY public.cupones_descs.id;


--
-- Name: cupones_usuarios; Type: TABLE; Schema: public; Owner: leo2
--

CREATE TABLE public.cupones_usuarios (
    id integer NOT NULL,
    canjeado boolean DEFAULT false NOT NULL,
    id_usuario integer,
    id_cupon integer
);


ALTER TABLE public.cupones_usuarios OWNER TO leo2;

--
-- Name: cupones_usuarios_id_seq; Type: SEQUENCE; Schema: public; Owner: leo2
--

CREATE SEQUENCE public.cupones_usuarios_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cupones_usuarios_id_seq OWNER TO leo2;

--
-- Name: cupones_usuarios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: leo2
--

ALTER SEQUENCE public.cupones_usuarios_id_seq OWNED BY public.cupones_usuarios.id;


--
-- Name: metodos_pagos; Type: TABLE; Schema: public; Owner: leo2
--

CREATE TABLE public.metodos_pagos (
    id integer NOT NULL,
    metodop character varying(255) NOT NULL
);


ALTER TABLE public.metodos_pagos OWNER TO leo2;

--
-- Name: metodos_pagos_id_seq; Type: SEQUENCE; Schema: public; Owner: leo2
--

CREATE SEQUENCE public.metodos_pagos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.metodos_pagos_id_seq OWNER TO leo2;

--
-- Name: metodos_pagos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: leo2
--

ALTER SEQUENCE public.metodos_pagos_id_seq OWNED BY public.metodos_pagos.id;


--
-- Name: ordenes_de_compras; Type: TABLE; Schema: public; Owner: leo2
--

CREATE TABLE public.ordenes_de_compras (
    id integer NOT NULL,
    fecha timestamp with time zone NOT NULL,
    total double precision NOT NULL,
    a_domicilio character varying(255) NOT NULL,
    direccion character varying(255) NOT NULL,
    clave_compra character varying(255) NOT NULL,
    id_usuario integer,
    id_cupon integer,
    id_metodop integer,
    id_producto integer
);


ALTER TABLE public.ordenes_de_compras OWNER TO leo2;

--
-- Name: ordenes_de_compras_id_seq; Type: SEQUENCE; Schema: public; Owner: leo2
--

CREATE SEQUENCE public.ordenes_de_compras_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ordenes_de_compras_id_seq OWNER TO leo2;

--
-- Name: ordenes_de_compras_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: leo2
--

ALTER SEQUENCE public.ordenes_de_compras_id_seq OWNED BY public.ordenes_de_compras.id;


--
-- Name: productos; Type: TABLE; Schema: public; Owner: leo2
--

CREATE TABLE public.productos (
    id integer NOT NULL,
    nombre_p character varying(255) NOT NULL,
    descripcion character varying(255) NOT NULL,
    precio character varying(255) NOT NULL,
    imagen character varying(255) NOT NULL,
    id_vendedor integer,
    id_categoria integer
);


ALTER TABLE public.productos OWNER TO leo2;

--
-- Name: productos_id_seq; Type: SEQUENCE; Schema: public; Owner: leo2
--

CREATE SEQUENCE public.productos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.productos_id_seq OWNER TO leo2;

--
-- Name: productos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: leo2
--

ALTER SEQUENCE public.productos_id_seq OWNED BY public.productos.id;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: leo2
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    nombre_rol character varying(255) NOT NULL
);


ALTER TABLE public.roles OWNER TO leo2;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: leo2
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.roles_id_seq OWNER TO leo2;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: leo2
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: tickets; Type: TABLE; Schema: public; Owner: leo2
--

CREATE TABLE public.tickets (
    id integer NOT NULL,
    cantidadp integer,
    precioxcantidad double precision,
    id_producto integer,
    id_compra integer
);


ALTER TABLE public.tickets OWNER TO leo2;

--
-- Name: tickets_id_seq; Type: SEQUENCE; Schema: public; Owner: leo2
--

CREATE SEQUENCE public.tickets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tickets_id_seq OWNER TO leo2;

--
-- Name: tickets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: leo2
--

ALTER SEQUENCE public.tickets_id_seq OWNED BY public.tickets.id;


--
-- Name: usuarios; Type: TABLE; Schema: public; Owner: leo2
--

CREATE TABLE public.usuarios (
    id integer NOT NULL,
    nombre_usu character varying(255) NOT NULL,
    apellidos_usu character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    telefono character varying(255) NOT NULL,
    ciudad character varying(255) NOT NULL,
    estado character varying(255) NOT NULL,
    direccion character varying(255) NOT NULL,
    codigo_postal character varying(255) NOT NULL,
    id_rol integer
);


ALTER TABLE public.usuarios OWNER TO leo2;

--
-- Name: usuarios_id_seq; Type: SEQUENCE; Schema: public; Owner: leo2
--

CREATE SEQUENCE public.usuarios_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.usuarios_id_seq OWNER TO leo2;

--
-- Name: usuarios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: leo2
--

ALTER SEQUENCE public.usuarios_id_seq OWNED BY public.usuarios.id;


--
-- Name: vendedores; Type: TABLE; Schema: public; Owner: leo2
--

CREATE TABLE public.vendedores (
    id integer NOT NULL,
    curp character varying(255) NOT NULL,
    rfc character varying(255) NOT NULL,
    ine character varying(255) NOT NULL,
    cuenta_banco character varying(255) NOT NULL,
    id_usuario integer
);


ALTER TABLE public.vendedores OWNER TO leo2;

--
-- Name: vendedores_id_seq; Type: SEQUENCE; Schema: public; Owner: leo2
--

CREATE SEQUENCE public.vendedores_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.vendedores_id_seq OWNER TO leo2;

--
-- Name: vendedores_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: leo2
--

ALTER SEQUENCE public.vendedores_id_seq OWNED BY public.vendedores.id;


--
-- Name: categorias_ps id; Type: DEFAULT; Schema: public; Owner: leo2
--

ALTER TABLE ONLY public.categorias_ps ALTER COLUMN id SET DEFAULT nextval('public.categorias_ps_id_seq'::regclass);


--
-- Name: cupones_descs id; Type: DEFAULT; Schema: public; Owner: leo2
--

ALTER TABLE ONLY public.cupones_descs ALTER COLUMN id SET DEFAULT nextval('public.cupones_descs_id_seq'::regclass);


--
-- Name: cupones_usuarios id; Type: DEFAULT; Schema: public; Owner: leo2
--

ALTER TABLE ONLY public.cupones_usuarios ALTER COLUMN id SET DEFAULT nextval('public.cupones_usuarios_id_seq'::regclass);


--
-- Name: metodos_pagos id; Type: DEFAULT; Schema: public; Owner: leo2
--

ALTER TABLE ONLY public.metodos_pagos ALTER COLUMN id SET DEFAULT nextval('public.metodos_pagos_id_seq'::regclass);


--
-- Name: ordenes_de_compras id; Type: DEFAULT; Schema: public; Owner: leo2
--

ALTER TABLE ONLY public.ordenes_de_compras ALTER COLUMN id SET DEFAULT nextval('public.ordenes_de_compras_id_seq'::regclass);


--
-- Name: productos id; Type: DEFAULT; Schema: public; Owner: leo2
--

ALTER TABLE ONLY public.productos ALTER COLUMN id SET DEFAULT nextval('public.productos_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: leo2
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: tickets id; Type: DEFAULT; Schema: public; Owner: leo2
--

ALTER TABLE ONLY public.tickets ALTER COLUMN id SET DEFAULT nextval('public.tickets_id_seq'::regclass);


--
-- Name: usuarios id; Type: DEFAULT; Schema: public; Owner: leo2
--

ALTER TABLE ONLY public.usuarios ALTER COLUMN id SET DEFAULT nextval('public.usuarios_id_seq'::regclass);


--
-- Name: vendedores id; Type: DEFAULT; Schema: public; Owner: leo2
--

ALTER TABLE ONLY public.vendedores ALTER COLUMN id SET DEFAULT nextval('public.vendedores_id_seq'::regclass);


--
-- Data for Name: categorias_ps; Type: TABLE DATA; Schema: public; Owner: leo2
--

COPY public.categorias_ps (id, categoria) FROM stdin;
\.
COPY public.categorias_ps (id, categoria) FROM '$$PATH$$/3089.dat';

--
-- Data for Name: cupones_descs; Type: TABLE DATA; Schema: public; Owner: leo2
--

COPY public.cupones_descs (id, descuento, dias_validez, activo, codigo) FROM stdin;
\.
COPY public.cupones_descs (id, descuento, dias_validez, activo, codigo) FROM '$$PATH$$/3091.dat';

--
-- Data for Name: cupones_usuarios; Type: TABLE DATA; Schema: public; Owner: leo2
--

COPY public.cupones_usuarios (id, canjeado, id_usuario, id_cupon) FROM stdin;
\.
COPY public.cupones_usuarios (id, canjeado, id_usuario, id_cupon) FROM '$$PATH$$/3093.dat';

--
-- Data for Name: metodos_pagos; Type: TABLE DATA; Schema: public; Owner: leo2
--

COPY public.metodos_pagos (id, metodop) FROM stdin;
\.
COPY public.metodos_pagos (id, metodop) FROM '$$PATH$$/3095.dat';

--
-- Data for Name: ordenes_de_compras; Type: TABLE DATA; Schema: public; Owner: leo2
--

COPY public.ordenes_de_compras (id, fecha, total, a_domicilio, direccion, clave_compra, id_usuario, id_cupon, id_metodop, id_producto) FROM stdin;
\.
COPY public.ordenes_de_compras (id, fecha, total, a_domicilio, direccion, clave_compra, id_usuario, id_cupon, id_metodop, id_producto) FROM '$$PATH$$/3097.dat';

--
-- Data for Name: productos; Type: TABLE DATA; Schema: public; Owner: leo2
--

COPY public.productos (id, nombre_p, descripcion, precio, imagen, id_vendedor, id_categoria) FROM stdin;
\.
COPY public.productos (id, nombre_p, descripcion, precio, imagen, id_vendedor, id_categoria) FROM '$$PATH$$/3099.dat';

--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: leo2
--

COPY public.roles (id, nombre_rol) FROM stdin;
\.
COPY public.roles (id, nombre_rol) FROM '$$PATH$$/3101.dat';

--
-- Data for Name: tickets; Type: TABLE DATA; Schema: public; Owner: leo2
--

COPY public.tickets (id, cantidadp, precioxcantidad, id_producto, id_compra) FROM stdin;
\.
COPY public.tickets (id, cantidadp, precioxcantidad, id_producto, id_compra) FROM '$$PATH$$/3103.dat';

--
-- Data for Name: usuarios; Type: TABLE DATA; Schema: public; Owner: leo2
--

COPY public.usuarios (id, nombre_usu, apellidos_usu, password, email, telefono, ciudad, estado, direccion, codigo_postal, id_rol) FROM stdin;
\.
COPY public.usuarios (id, nombre_usu, apellidos_usu, password, email, telefono, ciudad, estado, direccion, codigo_postal, id_rol) FROM '$$PATH$$/3105.dat';

--
-- Data for Name: vendedores; Type: TABLE DATA; Schema: public; Owner: leo2
--

COPY public.vendedores (id, curp, rfc, ine, cuenta_banco, id_usuario) FROM stdin;
\.
COPY public.vendedores (id, curp, rfc, ine, cuenta_banco, id_usuario) FROM '$$PATH$$/3107.dat';

--
-- Name: categorias_ps_id_seq; Type: SEQUENCE SET; Schema: public; Owner: leo2
--

SELECT pg_catalog.setval('public.categorias_ps_id_seq', 5, true);


--
-- Name: cupones_descs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: leo2
--

SELECT pg_catalog.setval('public.cupones_descs_id_seq', 8, true);


--
-- Name: cupones_usuarios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: leo2
--

SELECT pg_catalog.setval('public.cupones_usuarios_id_seq', 1, false);


--
-- Name: metodos_pagos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: leo2
--

SELECT pg_catalog.setval('public.metodos_pagos_id_seq', 2, true);


--
-- Name: ordenes_de_compras_id_seq; Type: SEQUENCE SET; Schema: public; Owner: leo2
--

SELECT pg_catalog.setval('public.ordenes_de_compras_id_seq', 23, true);


--
-- Name: productos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: leo2
--

SELECT pg_catalog.setval('public.productos_id_seq', 16, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: leo2
--

SELECT pg_catalog.setval('public.roles_id_seq', 2, true);


--
-- Name: tickets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: leo2
--

SELECT pg_catalog.setval('public.tickets_id_seq', 2, true);


--
-- Name: usuarios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: leo2
--

SELECT pg_catalog.setval('public.usuarios_id_seq', 27, true);


--
-- Name: vendedores_id_seq; Type: SEQUENCE SET; Schema: public; Owner: leo2
--

SELECT pg_catalog.setval('public.vendedores_id_seq', 1, true);


--
-- Name: categorias_ps categorias_ps_categoria_key; Type: CONSTRAINT; Schema: public; Owner: leo2
--

ALTER TABLE ONLY public.categorias_ps
    ADD CONSTRAINT categorias_ps_categoria_key UNIQUE (categoria);


--
-- Name: categorias_ps categorias_ps_pkey; Type: CONSTRAINT; Schema: public; Owner: leo2
--

ALTER TABLE ONLY public.categorias_ps
    ADD CONSTRAINT categorias_ps_pkey PRIMARY KEY (id);


--
-- Name: cupones_descs cupones_descs_pkey; Type: CONSTRAINT; Schema: public; Owner: leo2
--

ALTER TABLE ONLY public.cupones_descs
    ADD CONSTRAINT cupones_descs_pkey PRIMARY KEY (id);


--
-- Name: cupones_usuarios cupones_usuarios_pkey; Type: CONSTRAINT; Schema: public; Owner: leo2
--

ALTER TABLE ONLY public.cupones_usuarios
    ADD CONSTRAINT cupones_usuarios_pkey PRIMARY KEY (id);


--
-- Name: metodos_pagos metodos_pagos_metodop_key; Type: CONSTRAINT; Schema: public; Owner: leo2
--

ALTER TABLE ONLY public.metodos_pagos
    ADD CONSTRAINT metodos_pagos_metodop_key UNIQUE (metodop);


--
-- Name: metodos_pagos metodos_pagos_pkey; Type: CONSTRAINT; Schema: public; Owner: leo2
--

ALTER TABLE ONLY public.metodos_pagos
    ADD CONSTRAINT metodos_pagos_pkey PRIMARY KEY (id);


--
-- Name: ordenes_de_compras ordenes_de_compras_pkey; Type: CONSTRAINT; Schema: public; Owner: leo2
--

ALTER TABLE ONLY public.ordenes_de_compras
    ADD CONSTRAINT ordenes_de_compras_pkey PRIMARY KEY (id);


--
-- Name: productos productos_pkey; Type: CONSTRAINT; Schema: public; Owner: leo2
--

ALTER TABLE ONLY public.productos
    ADD CONSTRAINT productos_pkey PRIMARY KEY (id);


--
-- Name: roles roles_nombre_rol_key; Type: CONSTRAINT; Schema: public; Owner: leo2
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_nombre_rol_key UNIQUE (nombre_rol);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: leo2
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: tickets tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: leo2
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_pkey PRIMARY KEY (id);


--
-- Name: usuarios usuarios_pkey; Type: CONSTRAINT; Schema: public; Owner: leo2
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_pkey PRIMARY KEY (id);


--
-- Name: vendedores vendedores_pkey; Type: CONSTRAINT; Schema: public; Owner: leo2
--

ALTER TABLE ONLY public.vendedores
    ADD CONSTRAINT vendedores_pkey PRIMARY KEY (id);


--
-- Name: cupones_usuarios cupones_usuarios_id_cupon_fkey; Type: FK CONSTRAINT; Schema: public; Owner: leo2
--

ALTER TABLE ONLY public.cupones_usuarios
    ADD CONSTRAINT cupones_usuarios_id_cupon_fkey FOREIGN KEY (id_cupon) REFERENCES public.cupones_descs(id) ON UPDATE CASCADE;


--
-- Name: cupones_usuarios cupones_usuarios_id_usuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: leo2
--

ALTER TABLE ONLY public.cupones_usuarios
    ADD CONSTRAINT cupones_usuarios_id_usuario_fkey FOREIGN KEY (id_usuario) REFERENCES public.usuarios(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ordenes_de_compras fk_producto; Type: FK CONSTRAINT; Schema: public; Owner: leo2
--

ALTER TABLE ONLY public.ordenes_de_compras
    ADD CONSTRAINT fk_producto FOREIGN KEY (id_producto) REFERENCES public.productos(id);


--
-- Name: ordenes_de_compras ordenes_de_compras_id_cupon_fkey; Type: FK CONSTRAINT; Schema: public; Owner: leo2
--

ALTER TABLE ONLY public.ordenes_de_compras
    ADD CONSTRAINT ordenes_de_compras_id_cupon_fkey FOREIGN KEY (id_cupon) REFERENCES public.cupones_descs(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ordenes_de_compras ordenes_de_compras_id_metodop_fkey; Type: FK CONSTRAINT; Schema: public; Owner: leo2
--

ALTER TABLE ONLY public.ordenes_de_compras
    ADD CONSTRAINT ordenes_de_compras_id_metodop_fkey FOREIGN KEY (id_metodop) REFERENCES public.metodos_pagos(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ordenes_de_compras ordenes_de_compras_id_usuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: leo2
--

ALTER TABLE ONLY public.ordenes_de_compras
    ADD CONSTRAINT ordenes_de_compras_id_usuario_fkey FOREIGN KEY (id_usuario) REFERENCES public.usuarios(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: productos productos_id_categoria_fkey; Type: FK CONSTRAINT; Schema: public; Owner: leo2
--

ALTER TABLE ONLY public.productos
    ADD CONSTRAINT productos_id_categoria_fkey FOREIGN KEY (id_categoria) REFERENCES public.categorias_ps(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: productos productos_id_vendedor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: leo2
--

ALTER TABLE ONLY public.productos
    ADD CONSTRAINT productos_id_vendedor_fkey FOREIGN KEY (id_vendedor) REFERENCES public.vendedores(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: tickets tickets_id_compra_fkey; Type: FK CONSTRAINT; Schema: public; Owner: leo2
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_id_compra_fkey FOREIGN KEY (id_compra) REFERENCES public.ordenes_de_compras(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: tickets tickets_id_producto_fkey; Type: FK CONSTRAINT; Schema: public; Owner: leo2
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_id_producto_fkey FOREIGN KEY (id_producto) REFERENCES public.productos(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: usuarios usuarios_id_rol_fkey; Type: FK CONSTRAINT; Schema: public; Owner: leo2
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_id_rol_fkey FOREIGN KEY (id_rol) REFERENCES public.roles(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: vendedores vendedores_id_usuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: leo2
--

ALTER TABLE ONLY public.vendedores
    ADD CONSTRAINT vendedores_id_usuario_fkey FOREIGN KEY (id_usuario) REFERENCES public.usuarios(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

